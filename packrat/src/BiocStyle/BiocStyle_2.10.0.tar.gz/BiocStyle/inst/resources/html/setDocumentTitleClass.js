document.addEventListener("DOMContentLoaded", function() {
  document.querySelector("h1").className = "title";
});
