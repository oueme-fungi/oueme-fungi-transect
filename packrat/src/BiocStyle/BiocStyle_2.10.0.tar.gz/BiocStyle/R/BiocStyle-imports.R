#' @importFrom knitr current_input hook_pdfcrop hook_plot_md hook_plot_tex knit_hooks knit_theme opts_chunk opts_hooks opts_knit set_header
#' @importFrom rmarkdown metadata knitr_options output_format pandoc_available pandoc_version
#' @importFrom stats setNames
#' @importFrom utils packageVersion
#' @importFrom yaml yaml.load
NULL
