require("Biostrings") || stop("unable to load Biostrings package")
Biostrings:::.test()
